<?php
    $username=$_POST[ 'username'];
    $email=$_POST['email'];
    $question=$_POST['question']; 
    
    print_r($username);
    print_r($email);
    
    
?>