<?php

  namespace ActiveCollab;

  /**
   * Base activeCollab exception
   */
  abstract class Exception extends \Exception {

  }
