<div id="node-service">
  <?php  print render($content); ?>
</div>